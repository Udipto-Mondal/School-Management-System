﻿namespace School_management_system
{
    partial class AdminLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminLogin));
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            btnLogin = new Button();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label2 = new Label();
            label1 = new Label();
            menuStrip1 = new MenuStrip();
            admissionToolStripMenuItem = new ToolStripMenuItem();
            newAdmissionToolStripMenuItem = new ToolStripMenuItem();
            feesToolStripMenuItem = new ToolStripMenuItem();
            studentDetailsToolStripMenuItem = new ToolStripMenuItem();
            searchStudentToolStripMenuItem = new ToolStripMenuItem();
            individualDetailsToolStripMenuItem = new ToolStripMenuItem();
            teachersToolStripMenuItem = new ToolStripMenuItem();
            addTeachersToolStripMenuItem = new ToolStripMenuItem();
            searchTeacherToolStripMenuItem = new ToolStripMenuItem();
            aboutUsToolStripMenuItem = new ToolStripMenuItem();
            exitToolStripMenuItem = new ToolStripMenuItem();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ButtonFace;
            panel1.BackgroundImageLayout = ImageLayout.Stretch;
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(btnLogin);
            panel1.Controls.Add(textBox2);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(542, 260);
            panel1.Name = "panel1";
            panel1.Size = new Size(300, 265);
            panel1.TabIndex = 8;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.pngtree_beautiful_admin_roles_line_vector_icon_png_image_2035379;
            pictureBox1.Location = new Point(130, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(82, 88);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // btnLogin
            // 
            btnLogin.Location = new Point(137, 222);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(75, 23);
            btnLogin.TabIndex = 4;
            btnLogin.Text = "LOGIN";
            btnLogin.UseVisualStyleBackColor = true;
            btnLogin.Click += btnLogin_Click;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI", 9F);
            textBox2.Location = new Point(121, 176);
            textBox2.Name = "textBox2";
            textBox2.PasswordChar = '*';
            textBox2.Size = new Size(133, 23);
            textBox2.TabIndex = 3;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(121, 124);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(133, 23);
            textBox1.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(29, 182);
            label2.Name = "label2";
            label2.Size = new Size(66, 17);
            label2.TabIndex = 1;
            label2.Text = "Password";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(26, 130);
            label1.Name = "label1";
            label1.Size = new Size(69, 17);
            label1.TabIndex = 0;
            label1.Text = "Username";
            // 
            // menuStrip1
            // 
            menuStrip1.GripStyle = ToolStripGripStyle.Visible;
            menuStrip1.Items.AddRange(new ToolStripItem[] { admissionToolStripMenuItem, feesToolStripMenuItem, studentDetailsToolStripMenuItem, teachersToolStripMenuItem, aboutUsToolStripMenuItem, exitToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.RenderMode = ToolStripRenderMode.Professional;
            menuStrip1.Size = new Size(984, 68);
            menuStrip1.TabIndex = 10;
            menuStrip1.Text = "menuStrip1";
            // 
            // admissionToolStripMenuItem
            // 
            admissionToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { newAdmissionToolStripMenuItem });
            admissionToolStripMenuItem.Image = (Image)resources.GetObject("admissionToolStripMenuItem.Image");
            admissionToolStripMenuItem.ImageAlign = ContentAlignment.MiddleLeft;
            admissionToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            admissionToolStripMenuItem.Name = "admissionToolStripMenuItem";
            admissionToolStripMenuItem.Size = new Size(135, 64);
            admissionToolStripMenuItem.Text = "Admission";
            // 
            // newAdmissionToolStripMenuItem
            // 
            newAdmissionToolStripMenuItem.Name = "newAdmissionToolStripMenuItem";
            newAdmissionToolStripMenuItem.Size = new Size(180, 22);
            newAdmissionToolStripMenuItem.Text = "New Admission";
            newAdmissionToolStripMenuItem.Click += newAdmissionToolStripMenuItem_Click;
            // 
            // feesToolStripMenuItem
            // 
            feesToolStripMenuItem.Image = Properties.Resources.icon_fees;
            feesToolStripMenuItem.ImageAlign = ContentAlignment.MiddleLeft;
            feesToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            feesToolStripMenuItem.Name = "feesToolStripMenuItem";
            feesToolStripMenuItem.Size = new Size(102, 64);
            feesToolStripMenuItem.Text = "Fees";
            // 
            // studentDetailsToolStripMenuItem
            // 
            studentDetailsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { searchStudentToolStripMenuItem, individualDetailsToolStripMenuItem });
            studentDetailsToolStripMenuItem.Image = (Image)resources.GetObject("studentDetailsToolStripMenuItem.Image");
            studentDetailsToolStripMenuItem.ImageAlign = ContentAlignment.MiddleLeft;
            studentDetailsToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            studentDetailsToolStripMenuItem.Name = "studentDetailsToolStripMenuItem";
            studentDetailsToolStripMenuItem.Size = new Size(158, 64);
            studentDetailsToolStripMenuItem.Text = "Student Details";
            // 
            // searchStudentToolStripMenuItem
            // 
            searchStudentToolStripMenuItem.Name = "searchStudentToolStripMenuItem";
            searchStudentToolStripMenuItem.Size = new Size(167, 22);
            searchStudentToolStripMenuItem.Text = "Search Student";
            // 
            // individualDetailsToolStripMenuItem
            // 
            individualDetailsToolStripMenuItem.Name = "individualDetailsToolStripMenuItem";
            individualDetailsToolStripMenuItem.Size = new Size(167, 22);
            individualDetailsToolStripMenuItem.Text = "Individual Details ";
            // 
            // teachersToolStripMenuItem
            // 
            teachersToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { addTeachersToolStripMenuItem, searchTeacherToolStripMenuItem });
            teachersToolStripMenuItem.Image = (Image)resources.GetObject("teachersToolStripMenuItem.Image");
            teachersToolStripMenuItem.ImageAlign = ContentAlignment.MiddleLeft;
            teachersToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            teachersToolStripMenuItem.Name = "teachersToolStripMenuItem";
            teachersToolStripMenuItem.Size = new Size(124, 64);
            teachersToolStripMenuItem.Text = "Teachers";
            // 
            // addTeachersToolStripMenuItem
            // 
            addTeachersToolStripMenuItem.Name = "addTeachersToolStripMenuItem";
            addTeachersToolStripMenuItem.Size = new Size(205, 22);
            addTeachersToolStripMenuItem.Text = "Add Teacher Information";
            // 
            // searchTeacherToolStripMenuItem
            // 
            searchTeacherToolStripMenuItem.Name = "searchTeacherToolStripMenuItem";
            searchTeacherToolStripMenuItem.Size = new Size(205, 22);
            searchTeacherToolStripMenuItem.Text = "Search Teacher ";
            // 
            // aboutUsToolStripMenuItem
            // 
            aboutUsToolStripMenuItem.Image = (Image)resources.GetObject("aboutUsToolStripMenuItem.Image");
            aboutUsToolStripMenuItem.ImageAlign = ContentAlignment.MiddleLeft;
            aboutUsToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            aboutUsToolStripMenuItem.Name = "aboutUsToolStripMenuItem";
            aboutUsToolStripMenuItem.Size = new Size(131, 64);
            aboutUsToolStripMenuItem.Text = "About Us ";
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Image = (Image)resources.GetObject("exitToolStripMenuItem.Image");
            exitToolStripMenuItem.ImageAlign = ContentAlignment.MiddleLeft;
            exitToolStripMenuItem.ImageScaling = ToolStripItemImageScaling.None;
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(98, 64);
            exitToolStripMenuItem.Text = "Exit";
            // 
            // AdminLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(984, 560);
            Controls.Add(panel1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "AdminLogin";
            Text = "AdminLogin";
            WindowState = FormWindowState.Maximized;
            Load += AdminLogin_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button btnLogin;
        private TextBox textBox2;
        private TextBox textBox1;
        private Label label2;
        private Label label1;
        private PictureBox pictureBox1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem admissionToolStripMenuItem;
        private ToolStripMenuItem newAdmissionToolStripMenuItem;
        private ToolStripMenuItem feesToolStripMenuItem;
        private ToolStripMenuItem studentDetailsToolStripMenuItem;
        private ToolStripMenuItem searchStudentToolStripMenuItem;
        private ToolStripMenuItem individualDetailsToolStripMenuItem;
        private ToolStripMenuItem teachersToolStripMenuItem;
        private ToolStripMenuItem addTeachersToolStripMenuItem;
        private ToolStripMenuItem searchTeacherToolStripMenuItem;
        private ToolStripMenuItem aboutUsToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
    }
}