﻿namespace School_management_system
{
    partial class New_Admission
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(New_Admission));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            pictureBox1 = new PictureBox();
            txtFullName = new TextBox();
            txtMobile = new TextBox();
            txtEmail = new TextBox();
            txtFatherName = new TextBox();
            txtMotherName = new TextBox();
            radioButtonMale = new RadioButton();
            radioButtonFemale = new RadioButton();
            dateTimePickerDOB = new DateTimePicker();
            txtAddress = new RichTextBox();
            btnSave = new Button();
            btnReset = new Button();
            label10 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 108);
            label1.Name = "label1";
            label1.Size = new Size(136, 21);
            label1.TabIndex = 0;
            label1.Text = "Registration NO:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Calibri", 14.25F, FontStyle.Bold);
            label2.Location = new Point(69, 151);
            label2.Name = "label2";
            label2.Size = new Size(90, 23);
            label2.TabIndex = 1;
            label2.Text = "Full Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Calibri", 14.25F, FontStyle.Bold);
            label3.Location = new Point(489, 191);
            label3.Name = "label3";
            label3.Size = new Size(134, 23);
            label3.TabIndex = 2;
            label3.Text = "Mother's Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Calibri", 14.25F, FontStyle.Bold);
            label4.Location = new Point(69, 193);
            label4.Name = "label4";
            label4.Size = new Size(69, 23);
            label4.TabIndex = 3;
            label4.Text = "Gender";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Calibri", 14.25F, FontStyle.Bold);
            label5.Location = new Point(69, 232);
            label5.Name = "label5";
            label5.Size = new Size(112, 23);
            label5.TabIndex = 4;
            label5.Text = "Dath of Birth";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Calibri", 14.25F, FontStyle.Bold);
            label6.Location = new Point(69, 273);
            label6.Name = "label6";
            label6.Size = new Size(97, 23);
            label6.TabIndex = 5;
            label6.Text = "Mobile NO";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Calibri", 14.25F, FontStyle.Bold);
            label7.Location = new Point(489, 157);
            label7.Name = "label7";
            label7.Size = new Size(124, 23);
            label7.TabIndex = 6;
            label7.Text = "Father's Name";
           
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Calibri", 14.25F, FontStyle.Bold);
            label8.Location = new Point(491, 290);
            label8.Name = "label8";
            label8.Size = new Size(75, 23);
            label8.TabIndex = 7;
            label8.Text = "Address";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Calibri", 14.25F, FontStyle.Bold);
            label9.Location = new Point(491, 232);
            label9.Name = "label9";
            label9.Size = new Size(74, 23);
            label9.TabIndex = 8;
            label9.Text = "Email ID";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(176, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(550, 85);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // txtFullName
            // 
            txtFullName.Location = new Point(243, 151);
            txtFullName.Name = "txtFullName";
            txtFullName.Size = new Size(148, 23);
            txtFullName.TabIndex = 10;
            // 
            // txtMobile
            // 
            txtMobile.Location = new Point(243, 273);
            txtMobile.Name = "txtMobile";
            txtMobile.Size = new Size(130, 23);
            txtMobile.TabIndex = 11;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(672, 232);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(142, 23);
            txtEmail.TabIndex = 12;
            // 
            // txtFatherName
            // 
            txtFatherName.Location = new Point(672, 157);
            txtFatherName.Name = "txtFatherName";
            txtFatherName.Size = new Size(142, 23);
            txtFatherName.TabIndex = 14;
            // 
            // txtMotherName
            // 
            txtMotherName.Location = new Point(672, 194);
            txtMotherName.Name = "txtMotherName";
            txtMotherName.Size = new Size(142, 23);
            txtMotherName.TabIndex = 15;
            // 
            // radioButtonMale
            // 
            radioButtonMale.AutoSize = true;
            radioButtonMale.Location = new Point(243, 193);
            radioButtonMale.Name = "radioButtonMale";
            radioButtonMale.Size = new Size(56, 19);
            radioButtonMale.TabIndex = 16;
            radioButtonMale.TabStop = true;
            radioButtonMale.Text = "MALE";
            radioButtonMale.UseVisualStyleBackColor = true;
            // 
            // radioButtonFemale
            // 
            radioButtonFemale.AutoSize = true;
            radioButtonFemale.Location = new Point(305, 192);
            radioButtonFemale.Name = "radioButtonFemale";
            radioButtonFemale.Size = new Size(68, 19);
            radioButtonFemale.TabIndex = 17;
            radioButtonFemale.TabStop = true;
            radioButtonFemale.Text = "FEMALE";
            radioButtonFemale.UseVisualStyleBackColor = true;
            // 
            // dateTimePickerDOB
            // 
            dateTimePickerDOB.Format = DateTimePickerFormat.Short;
            dateTimePickerDOB.Location = new Point(243, 226);
            dateTimePickerDOB.Name = "dateTimePickerDOB";
            dateTimePickerDOB.Size = new Size(130, 23);
            dateTimePickerDOB.TabIndex = 18;
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(633, 276);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(158, 59);
            txtAddress.TabIndex = 19;
            txtAddress.Text = "";
            // 
            // btnSave
            // 
            btnSave.Location = new Point(298, 399);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 20;
            btnSave.Text = "Submit";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnReset
            // 
            btnReset.Location = new Point(463, 399);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(75, 23);
            btnReset.TabIndex = 21;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(176, 113);
            label10.Name = "label10";
            label10.Size = new Size(44, 15);
            label10.TabIndex = 22;
            label10.Text = "label10";
            // 
            // New_Admission
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(873, 495);
            Controls.Add(label10);
            Controls.Add(btnReset);
            Controls.Add(btnSave);
            Controls.Add(txtAddress);
            Controls.Add(dateTimePickerDOB);
            Controls.Add(radioButtonFemale);
            Controls.Add(radioButtonMale);
            Controls.Add(txtMotherName);
            Controls.Add(txtFatherName);
            Controls.Add(txtEmail);
            Controls.Add(txtMobile);
            Controls.Add(txtFullName);
            Controls.Add(pictureBox1);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "New_Admission";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "New_Admission";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private PictureBox pictureBox1;
        private TextBox txtFullName;
        private TextBox txtMobile;
        private TextBox txtEmail;
        private TextBox txtFatherName;
        private TextBox txtMotherName;
        private RadioButton radioButtonMale;
        private RadioButton radioButtonFemale;
        private DateTimePicker dateTimePickerDOB;
        private RichTextBox txtAddress;
        private Button btnSave;
        private Button btnReset;
        private Label label10;
    }
}