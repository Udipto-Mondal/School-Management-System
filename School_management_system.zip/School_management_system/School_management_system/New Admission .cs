﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace School_management_system
{
    public partial class New_Admission : Form
    {
        public New_Admission()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Collect user inputs
            string name = txtFullName.Text;
            string gender = radioButtonMale.Checked ? radioButtonMale.Text : radioButtonFemale.Text;
            string dob = dateTimePickerDOB.Text;
            string faname = txtFatherName.Text;
            string mname = txtMotherName.Text;
            string email = txtEmail.Text;
            string add = txtAddress.Text;

            // Ensure mobile number is valid
            if (!Int64.TryParse(txtMobile.Text, out Int64 mobile))
            {
                MessageBox.Show("Invalid mobile number. Please enter numbers only.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Database connection string
            string connectionString = "data source=DESKTOP-CQN3A53\\SQLEXPRESS;database=college;integrated security=True";

            // Using block to ensure the connection is properly closed
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();  // Open database connection

                    // SQL query with parameters to prevent SQL Injection
                    string query = "INSERT INTO NewAdmission(fname, gender, dob, mobile, mname, faname, email, address) " +
                                   "VALUES (@fname, @gender, @dob, @mobile, @mname, @faname, @email, @address)";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        // Adding parameters to prevent SQL Injection
                        cmd.Parameters.AddWithValue("@fname", name);
                        cmd.Parameters.AddWithValue("@gender", gender);
                        cmd.Parameters.AddWithValue("@dob", dob);
                        cmd.Parameters.AddWithValue("@mobile", mobile);
                        cmd.Parameters.AddWithValue("@mname", mname);
                        cmd.Parameters.AddWithValue("@faname", faname);
                        cmd.Parameters.AddWithValue("@email", email);
                        cmd.Parameters.AddWithValue("@address", add);

                        // Execute the query
                        cmd.ExecuteNonQuery();
                    }

                    // Show success message
                    MessageBox.Show("New admission record saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    // Show error message if there is any exception
                    MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }  // Connection is closed automatically here
        }
    }
}
