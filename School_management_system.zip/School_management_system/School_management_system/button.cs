namespace School_management_system
{
    public partial class button : Form
    {
        public button()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
        
        {
            AdminLogin adminLogin = new AdminLogin();
            adminLogin.ShowDialog(); // from ,.,..,,.,..,.,.,
        }

    }
}
}
